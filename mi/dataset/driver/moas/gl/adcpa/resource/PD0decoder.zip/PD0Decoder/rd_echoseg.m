%-------------------------------------
function ens=rd_echoseg(fd,ens);
% Reads the echo intensities

for n = 1:ens.fixed.n_cells
    for bm = 1:4
        ens.intens(n,bm)=fread(fd,1,'uint8');   % Depth Cell #n, Field #bm
    end
end