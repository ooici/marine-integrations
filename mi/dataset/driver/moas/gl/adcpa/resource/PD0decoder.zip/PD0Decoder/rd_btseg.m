function ens=rd_btseg(fd,ens);
% Reads the bottom track data

ens.bt=struct('pings_per_ens',zeros(2,1),'delay',zeros(2,1),...
            'corr_mag_min',zeros(1,1),'eval_amp_min',zeros(1,1),...
            'mode',zeros(1,1),'err_vel_max',zeros(1,1),...
            'range',zeros(4,1),'vel',zeros(4,1),...
    	    'corr',zeros(4,1),'ampl',zeros(4,1),'perc_good',zeros(4,1),'ref_layer',zeros(6,1),...
            'ref_vel',zeros(8,1), 'ref_corr',zeros(4,1),'ref_int',zeros(4,1),...
            'ref_pg',zeros(4,1), 'max_depth',zeros(1,1), 'rssi',zeros(4,1),...
            'gain',zeros(1,1), 'range_msb',zeros(4,1));

        
ens.bt.pings_per_ens    =fread(fd,1,'uint16');      % BT Pings Per Ensemble (BP)
ens.bt.delay            =fread(fd,1,'uint16');      % BT Delay Before Re-Acquire (BD)
ens.bt.corr_mag_min     =fread(fd,1,'uint8');       % BT Corr Mag Min (BC)
ens.bt.eval_amp_min     =fread(fd,1,'uint8');       % BT Eval Amp Min (BA)
fseek(fd,1,'cof');                              % Reserved
ens.bt.mode             =fread(fd,1,'uint8');       % BT Mode (BM)
ens.bt.err_vel_max      =fread(fd,1,'uint16');       % BT Err Vel Max (BE)
fseek(fd,4,'cof');                              % Reserved
ens.bt.range            =fread(fd,4,'uint16')*.01;  % Beams #1-4 BT Range  cm
ens.bt.vel              =fread(fd,4,'int16');       % Beams #1-4 Velocity
ens.bt.corr             =fread(fd,4,'uint8');       % Beams #1-4 Corr
ens.bt.ampl             =fread(fd,4,'uint8');       % Beams #1-4 Eval Amp
ens.bt.perc_good        =fread(fd,4,'uint8');       % Beams #1-4 Percent Good
ens.bt.ref_layer        =fread(fd,6,'uint8');       % Ref Layer Min,Near,Far (BL)
ens.bt.ref_vel          =fread(fd,4,'int16');       % Beams #1-4 Ref Layer Vel
ens.bt.ref_corr         =fread(fd,4,'uint8');       % Beams #1-4 Ref Corr
ens.bt.ref_int          =fread(fd,4,'uint8');       % Beams #1-4 Ref Int
ens.bt.ref_pg           =fread(fd,4,'uint8');       % Beams #1-4 Ref PG
ens.bt.max_depth        =fread(fd,1,'int16')*.1;    % BT Max Depth (BX)  dm
ens.bt.rssi             =fread(fd,4,'uint8');       % Beams #1-4 RSSI Amp
ens.bt.gain             =fread(fd,1,'uint8');       % Gain
ens.bt.range_msb        =fread(fd,4,'uint8');       % Beams #1-4 Range MSB