%--------------------------------------
function ens=rd_hdrseg(fd)
% Reads a Header
ens.headerid           =dec2hex(fread(fd,2,'uint8'));   % Header id 7F7F
ens.hdr.nbyte          =fread(fd,1,'int16');            % Number of Bytes in Ensemble
fseek(fd,1,'cof');                                      % Spare
ens.hdr.ndat           =fread(fd,1,'int8');             % Number of Data Types
ens.hdr.dat_offsets    =fread(fd,ens.hdr.ndat,'int16'); % Offset For Data Type #1-N