%-------------------------------------
function ens=rd_velseg(fd,ens)
% Reads the velocity data

for n = 1:ens.fixed.n_cells
    ens.vel_1(n,1)=fread(fd,1,'int16');   % Depth Cell #n, Vel_1  mm/s
    ens.vel_2(n,1)=fread(fd,1,'int16');   % Depth Cell #n, Vel_2  mm/s
    ens.vel_3(n,1)=fread(fd,1,'int16');   % Depth Cell #n, Vel_3  mm/s
    ens.vel_4(n,1)=fread(fd,1,'int16');   % Depth Cell #n, Vel_4  mm/s 
end