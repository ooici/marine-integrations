%-------------------------------------
function ens=rd_fixseg(fd,ens)
% Reads the configuration data from the fixed leader
ens.fixed.name='wh-adcp'; % initialize with this value and then figure based on fw
ens.fixed.sourceprog='Instrument';  % default - depending on what data blocks are
                              % around we can modify this later in rd_buffer.
ens.fixed.prog_ver       =fread(fd,1,'uint8')+fread(fd,1,'uint8')/100;
if fix(ens.fixed.prog_ver)==50,
    ens.fixed.name='WH Exportable';
elseif fix(ens.fixed.prog_ver)==16 | fix(ens.fixed.prog_ver)==51 | fix(ens.fixed.prog_ver)==52,
    ens.fixed.name='WH Mar/Mon/Sent/LR';
elseif fix(ens.fixed.prog_ver)==9,
    ens.fixed.name='WH Navigator';
elseif fix(ens.fixed.prog_ver)==10,
    ens.fixed.name='WH RioGrande';
elseif fix(ens.fixed.prog_ver)==11,
    ens.fixed.name='WH Horizontal';
elseif fix(ens.fixed.prog_ver)==34 %explorer
    ens.fixed.name='WH Explorer';
elseif fix(ens.fixed.prog_ver)==37 % PTIC
    ens.fixed.name='PTIC';
else
    ens.fixed.name='Unrecognized Firmware Version';    
end;     

century=2000;  % century created after 2000 so century not in  ensemble  
config         =fread(fd,2,'uint8');  % System Configuration

ens.fixed.config         =[dec2base(config(2),2,8) '-' dec2base(config(1),2,8)];
ens.fixed.beam_angle     =getopt(bitand(config(2),3),15,20,30);
ens.fixed.numbeams       =getopt(bitand(config(2),16)==16,4,5);
ens.fixed.beam_freq      =getopt(bitand(config(1),7),75,150,300,600,1200,2400,38);
ens.fixed.beam_pattern   =getopt(bitand(config(1),8)==8,'concave','convex'); % 1=convex,0=concave
ens.fixed.orientation    =getopt(bitand(config(1),128)==128,'down','up');    % 1=up,0=down
ens.fixed.simflag        =getopt(fread(fd,1,'uint8'),'real','simulated'); % Real/Sim Flag
fseek(fd,1,'cof');                              % Lag Length
ens.fixed.n_beams        =fread(fd,1,'uint8');        % Number of Beams
ens.fixed.n_cells        =fread(fd,1,'uint8');        % Number of Cells (WN)
ens.fixed.pings_per_ensemble=fread(fd,1,'uint16');    % Pings per Ensemble (WP)
ens.fixed.cell_size      =fread(fd,1,'uint16')*.01;	% Depth Cell Legth (WS) meters
ens.fixed.blank          =fread(fd,1,'uint16')*.01;	% Blank After Transmit (WF) meters
ens.fixed.prof_mode      =fread(fd,1,'uint8');        % Profiling Mode (WM)
ens.fixed.corr_threshold =fread(fd,1,'uint8');        % Low Correlation Threshold (WC)
ens.fixed.n_codereps     =fread(fd,1,'uint8');        % Number of Code Reps
ens.fixed.min_pgood      =fread(fd,1,'uint8');        % Percent Good Minimum (WG)
ens.fixed.err_vel_thresh =fread(fd,1,'uint16');       % Error Velocity Max (WE)
ens.fixed.time_btwn_pings=sum(fread(fd,3,'uint8').*[60 1 .01]'); % TPP Minutes  seconds
                                                                    % TPP Seconds  seconds
                                                                    % TPP Hundreths  seconds
coord_sys          =fread(fd,1,'uint8');        % Coordinate Transform (EX)
ens.fixed.coord=dec2base(coord_sys,2,5);              % Actual bits of EX setting (ex.- if EX11111, ens.fixed.coord = '11111')
% --------------------decipher EX setting---------------------------------
ens.fixed.coord_sys =getopt(bitand(bitshift(coord_sys,-3),3),'beam','instrument','ship','earth');  
adcp.coordStr = getopt(bitand(bitshift(coord_sys,-3),3),'beam','instrument','ship','earth'); 
coordStr= getopt(bitand(bitshift(coord_sys,-3),3),'beam','instrument','ship','earth');       
ens.fixed.use_pitchroll  =getopt(bitand(coord_sys,4)==4,'no','yes');  
ens.fixed.use_3beam      =getopt(bitand(coord_sys,2)==2,'no','yes');
ens.fixed.bin_mapping    =getopt(bitand(coord_sys,1)==1,'no','yes');
% --------------------decipher EX setting---------------------------------
ens.fixed.xducer_misalign=fread(fd,1,'int16')*.01;    % Heading Alignment (EA) degrees
ens.fixed.magnetic_var   =fread(fd,1,'int16')*.01;	% Heading Bias (EB) degrees
ens.fixed.sensors_src    =dec2base(fread(fd,1,'uint8'),2,8);  % Sensor Source (EZ)
ens.fixed.sensors_avail  =dec2base(fread(fd,1,'uint8'),2,8);  % Sensors Available
ens.fixed.bin1_dist      =fread(fd,1,'uint16')*.01;	% Bin 1 Distance  meters
ens.fixed.xmit_pulse     =fread(fd,1,'uint16')*.01;	% Xmit Pulse Length (WT)  meters
ens.fixed.water_ref_cells=fread(fd,2,'uint8');        % (starting cell) WP Ref Layer Average (WL) (ending cell)
ens.fixed.fls_target_threshold =fread(fd,1,'uint8');  % False Target Threshold (WA)
fseek(fd,1,'cof');                              % Spare (skipped)
ens.fixed.xmit_lag       =fread(fd,1,'uint16')*.01;   % Transmit Lag Distance  meters
% Mar/Mon/Sent/LR = Exportable = RioGrande = Horizontal  remaining fixed data
if fix(ens.fixed.prog_ver)==10 | fix(ens.fixed.prog_ver)==11 | fix(ens.fixed.prog_ver)==16 | fix(ens.fixed.prog_ver)==51 | fix(ens.fixed.prog_ver)==52,
    ens.fixed.cpu_serialnum   =dec2hex(fread(fd,8,'uint8'));       % CPU Board Serial Number
    ens.fixed.sysbandwidth    =fread(fd,2,'uint8');       % System Bandwidth (WB)
    ens.fixed.syspower        =fread(fd,1,'uint8');       % System Power (CQ)
    fseek(fd,1,'cof');                              % Spare (skipped)
    ens.fixed.inst_serianum   =dec2hex(fread(fd,4,'uint8'));       % Instrument Serial Number
    ens.fixed.beam_angle      =fread(fd,1,'uint8');       % Beam Angle
% Navigator  remaining fixed data
elseif fix(ens.fixed.prog_ver)==9 | fix(ens.fixed.prog_ver)==37,
    ens.fixed.cpu_serialnum   =fread(fd,8,'uint8');       % CPU Board Serial Number
    ens.fixed.sysbandwidth    =fread(fd,2,'uint8');       % System Bandwidth (WB)
    ens.fixed.syspower        =fread(fd,1,'uint8');       % System Power (CQ)
    ens.fixed.base_freq_idx   =fread(fd,1,'uint8');       % Base Frequency Index    
% Explorer  remaining fixed data
elseif fix(ens.fixed.prog_ver)==34,
    fseek(fd,8,'cof');                              % Spare (skipped)
    ens.fixed.sysbandwidth    =fread(fd,2,'uint8');       % System Bandwidth (WB)
    fseek(fd,2,'cof');                              % Spare (skipped)
    ens.fixed.sys_serialnum   =fread(fd,4,'uint8');       % System Serial Number
else
    ens.fixed.sys_serialnum=0;
end;

% It is useful to have this precomputed.

ens.fixed.ranges=ens.fixed.bin1_dist+(0:ens.fixed.n_cells-1)'*ens.fixed.cell_size;
if ens.fixed.orientation==1, 
    ens.fixed.ranges=-ens.fixed.ranges; 
end