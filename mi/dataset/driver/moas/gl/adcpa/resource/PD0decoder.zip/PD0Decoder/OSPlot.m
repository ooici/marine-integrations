figure;
hold

subplot(2,2,1)
plot(ens(1).vel_1(1:15),1:15);
title('Beam 1');

subplot(2,2,2)
plot(ens(1).vel_2(1:15),1:15);
title('Beam 2');

subplot(2,2,3)
plot(ens(1).vel_3(1:15),1:15);
title('Beam 3');

subplot(2,2,4)
plot(ens(1).vel_4(1:15),1:15);
title('Beam 4');