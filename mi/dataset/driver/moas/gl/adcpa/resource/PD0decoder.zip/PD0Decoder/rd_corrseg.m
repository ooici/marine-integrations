%-------------------------------------
function ens=rd_corrseg(fd,ens);
% Reads the corrleation

for n = 1:ens.fixed.n_cells
    for bm = 1:4
        ens.corr(n,bm)=fread(fd,1,'uint8');   % Depth Cell #n, Field #bm
    end
end