%-------------------------------------
function ens=rd_pgseg(fd,ens);
% Reads the percent goods

for n = 1:ens.fixed.n_cells
    for bm = 1:4
        ens.pg(n,bm)=fread(fd,1,'uint8');   % Depth Cell #n, Field #bm
    end
end