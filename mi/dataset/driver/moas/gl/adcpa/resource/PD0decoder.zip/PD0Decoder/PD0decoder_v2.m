% =========================================================================
% Louis Morda - Teledyne RDI - 5/6/09
% 
% This program decodes PD0 data files from the following Workhorse products:
% Mar, Mon, Sent, LongRanger, RioGrande, Navigator, Horizontal, Explorer.
% The decoding sequence used in this model is taken from Chaper 7 of the
% Workhorse Commands and Output Data Format manual, November 2007.
% This model is loosely based on the ADCP decoder written by R. Pawlowicz
% www.eos.ubc.ca/~rich/research.html. 
% 
% To use this model simply change the 'filename' variable to the name of your
% PD0 data file.  The decoder creates a Matlab struct 'ens'.
%
% The 'ens' struct array is 1xN, where N is the number of ensembles in the 
% PD0 data file.  The indexing works like this:
% Ens #1 = ens(1) 
% Ens #2 = ens(2)
% .
% .
% Example: If you would like to see the data fields for ensemble #5, type 
% "ens(5)" at the MATLAB prompt.
% Example: To list velocity data for ensemble #5, type "ens(5).vel_1", all
% of the bin velocities for beam1 will be output.
% Example: To list the fixed leader data, type "ens(n).fixed" where n is
% the ensemble number you would like to see.  If you would like to only see
% the coordinate system, type "ens(n).fixed.coord_sys".
% AP: 10/14/2010 - Added special case for Jerry (ensemble size suddenly
%                  changing because of extra BT)
% =========================================================================
clear all;
filename = input('File name (include extension)? ','s');
% =========================================================================
% User settings
% =========================================================================
name = filename; % Name of PD0 data file
% =========================================================================
% Init Vars
% =========================================================================
nbyte = 0;
fseek_status = 0;
nens = 1;
headerid = '0000';
fprintf('\nOpening file %s\n\n',name);
fd=fopen(name,'r','ieee-le');
if fd == -1
   fd = fopen(name, 'r');
end;
ngood = 0;
firstbad = 0;

% =========================================================================
% Checksum Calculation and Header Data
% ========================================================================= 
while (fseek_status > -1)
    checksum = 0;
    headerid=fread(fd,2,'uint8');  % Hopefully read header id 7F7F
    if isempty(headerid),          % If nothing read then at end of file
       fprintf('\nEnd of file');
       break;
       
    elseif (headerid(1) == 127) & (headerid(2) == 127)
        ens_nbyte = fread(fd,1,'int16');  % Read number of bytes in ens
        fseek(fd, nbyte,'bof');  % Return file position indicator to beginning of ensemble
        for bytenum=1:ens_nbyte  % Add all bytes except for ensemble checksum
            checksum = checksum + fread(fd,1,'uint8') ;
        end
        checksum = mod(checksum,65536);
        read_checksum = fread(fd,1,'uint16');
        if checksum == read_checksum  % Compare calculated checksum and ens checksum
            ngood = nbyte;
            fseek(fd,nbyte,'bof');    % Jump to the right ensemble number
            ens_i=rd_hdrseg(fd);      % Header data  (creates and stores data in 'hdr' struct)
            nobt = 1;
    			% =========================================================================
    			% Fixed Leader, Variable Leader, Velocity, Corr, Echo, PG, All Data Types
          	% =========================================================================
            for n=1:length(ens_i.hdr.dat_offsets),
                fseek(fd,ens_i.hdr.dat_offsets(n)+nbyte,'bof');  % Offset for ensemble #nens, Data Type #n
                id=dec2hex(fread(fd,1,'uint16'),4);        % Read data type ID
                switch id,         
                   case '0000',   % Fixed leader 
                        ens_i=rd_fixseg(fd,ens_i);
                   case '0080'   % Variable Leader        
                        ens_i=rd_varseg(fd,ens_i);
                   case '0100'   % Velocity Data
                        ens_i=rd_velseg(fd,ens_i);
                   case '0200'   % Correlation Magnitude Data
                        ens_i=rd_corrseg(fd,ens_i);
                   case '0300'   % Echo Intensity Data
                        ens_i=rd_echoseg(fd,ens_i);
                   case '0400'   % Percent Good Data
                        ens_i=rd_pgseg(fd,ens_i);
                   case '0600'   % Bottom Track Data  
                      	ens_i=rd_btseg(fd,ens_i);
                      	nobt = 0;
                end
            end;
            
            % Always add bt structure
            if nobt > 0
               ens_i.bt=struct('pings_per_ens',zeros(2,1),'delay',zeros(2,1),...
            	'corr_mag_min',zeros(1,1),'eval_amp_min',zeros(1,1),...
            	'mode',zeros(1,1),'err_vel_max',zeros(1,1),...
            	'range',zeros(4,1),'vel',zeros(4,1),...
    	    		'corr',zeros(4,1),'ampl',zeros(4,1),'perc_good',zeros(4,1),'ref_layer',zeros(6,1),...
            	'ref_vel',zeros(8,1), 'ref_corr',zeros(4,1),'ref_int',zeros(4,1),...
            	'ref_pg',zeros(4,1), 'max_depth',zeros(1,1), 'rssi',zeros(4,1),...
            	'gain',zeros(1,1), 'range_msb',zeros(4,1));
            end

            ens(nens) = ens_i;
            fprintf('Ensemble number %d decoded\n', nens);
            nens = nens + 1;
            nbyte = nbyte+ens_i.hdr.nbyte+2;
        		fseek_status = fseek(fd,nbyte,'bof');
        else
           fprintf('\nBad checksum, throwing ensemble away (byte %d)', nbyte);
           nbyte = nbyte + 1;
           fseek_status = fseek(fd,nbyte,'bof');
           break;
        end;
     else
        nbyte = nbyte + 1;
        fseek_status = fseek(fd,nbyte,'bof');

	  end;      
      
 end;
fclose('all');