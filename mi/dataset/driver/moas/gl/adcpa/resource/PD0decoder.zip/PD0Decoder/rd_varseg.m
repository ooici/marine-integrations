%-------------------------------------
function ens=rd_varseg(fd,ens);
% Reads the data from the variable leader

ens.var=struct('number',zeros(1),'rtc',zeros(7,1),'BIT',zeros(1,1),'ssp',zeros(1,1),'depth',zeros(1,1),'pitch',zeros(1,1),...
            'roll',zeros(1,1),'heading',zeros(1,1),'temperature',zeros(1,1),'salinity',zeros(1,1),...
            'mpt',zeros(1,1),'heading_std',zeros(1,1),'pitch_std',zeros(1,1),...
            'roll_std',zeros(1,1),'adc',zeros(8,1),'error_status_wd',zeros(1,1),...
            'pressure',zeros(1,1),'pressure_std',zeros(1,1),...
            'vel_1',zeros(ens.fixed.n_cells,1),'vel_2',zeros(ens.fixed.n_cells,1),'vel_3',zeros(ens.fixed.n_cells,1),...
            'vel_4',zeros(ens.fixed.n_cells,1),'intvar',zeros(ens.fixed.n_cells,4,1),'pg',zeros(ens.fixed.n_cells,4,1),...
            'corr',zeros(ens.fixed.n_cells,4,1),'status',zeros(ens.fixed.n_cells,4,1));
    
ens.var.number       =fread(fd,1,'uint16');    % varemble Number
ens.var.rtc          =fread(fd,7,'uint8');     % RTC Time Stamp
ens.var.number       =ens.var.number+65536*fread(fd,1,'uint8'); % varemble # MSB
ens.var.BIT          =fread(fd,1,'uint16');    % BIT Result
ens.var.speed_of_sound=fread(fd,1,'uint16');    % Speed of Sound (EC)
ens.var.depth        =fread(fd,1,'uint16')*.1; % Depth of Transducer (ED) meters
ens.var.heading      =fread(fd,1,'uint16')*.01;% Heading (EH) degrees
ens.var.pitch        =fread(fd,1,'int16')*.01; % Pitch (Tilt 1) (EP) degrees
ens.var.roll         =fread(fd,1,'int16')*.01; % Roll (Tilt 2) (ER) degrees
ens.var.salinity     =fread(fd,1,'int16');     % Salinity (ES)
ens.var.temperature  =fread(fd,1,'int16')*.01; % Temperature (ET) Deg C
ens.var.mpt          =sum(fread(fd,3,'uint8').*[60 1 .01]'); % MPT seconds
ens.var.heading_std  =fread(fd,1,'uint8');     % Hdg Std Dev degrees
ens.var.pitch_std    =fread(fd,1,'int8')*.1;   % Pitch Std Dev degrees
ens.var.roll_std     =fread(fd,1,'int8')*.1;   % Roll Std Dev degrees
ens.var.adc          =fread(fd,8,'uint8');     % ADC Channel 0-7
ens.var.esw          =fread(fd,4,'uint8');     % Error Status Word (ESW) (CY)
fseek(fd,2,'cof');                         % Spare (skipped)
ens.var.pressure     =fread(fd,1,'uint32')*.01;     % Pressure (Pascal)
ens.var.pressure_var =fread(fd,1,'uint32')*.01;     % Pressure Svaror Variance (Pascal)
fseek(fd,1,'cof');                         % Spare (skipped)
ens.fixed.prog_ver = fread(fd,8,'uint8');
if (fix(ens.fixed.prog_ver)==9 | fix(ens.fixed.prog_ver)==10 | fix(ens.fixed.prog_ver)==11 | fix(ens.fixed.prog_ver)==16 | fix(ens.fixed.prog_ver)==34 | fix(ens.fixed.prog_ver) == 50 | fix(ens.fixed.prog_ver)==51 | fix(ens.fixed.prog_ver)==52 )
   ens.var.rtc_y2k  =fread(fd,8,'uint8');     % RTC Y2K Time Stamp
elseif (fix(ens.fixed.prog_ver)==34)
    fseek(fd,3,'cof');                         % Spare (skipped)
end
